# "Node JS Tutorial Series - MongoDB with Mongoose" by Dave Gray

[<img src="https://cdn.gomix.com/2bdfb3f8-05ef-4035-a06e-2043962a3a13%2Fremix-button.svg" width="163px" />](https://glitch.com/edit/#!/import/github/BlairLi/Node-JS-Tutorial-Series)

**Deploy by clicking the button above**
_Remember to add your .env variables in the deployed version_

**Description:**

This repository shares the code applied during the Youtube tutorial. The tutorial is part of a [Node.js & Express for Beginners Playlist](https://www.youtube.com/playlist?list=PL0Zuz27SZ-6PFkIxaJ6Xx_X46avTM1aYw).  

[YouTube Tutorial](https://youtu.be/-PdjUx9JZ2E) for this repository.

### Academic Honesty

**DO NOT COPY FOR AN ASSIGNMENT** - Avoid plagiargism and adhere to the spirit of this [Academic Honesty Policy](https://www.freecodecamp.org/news/academic-honesty-policy/).
